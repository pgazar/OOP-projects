package RPGpackage;

public enum HeadGearType {
  HATS,
  HELMETS,
  VISORS
}
