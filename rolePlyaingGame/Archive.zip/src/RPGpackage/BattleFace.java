package RPGpackage;

public interface BattleFace {


  String startBattle();
}
