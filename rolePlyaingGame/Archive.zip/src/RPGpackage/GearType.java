package RPGpackage;

public enum GearType {

  HEAD_GEAR,
  HAND_GEAR,
  FOOT_GEAR
}
