package RPGpackage;

public enum FootGearType {

  BOOTS,
  SNEAKERS,
  HOVERBOARDS

}



