package RPGpackage;

public enum HandGearType {
  GLOVES,
  SWORDS,
  SHEILDS

}
